# Dark Energy Character Sheet for Roll20

This repository contains the code to build the character sheet for Dark Energy for Roll20

## Usage

### Requirements

 * Ruby 2.6.3
 * Recommended: Roll20 Autouploader

### Installation steps

#### Install ruby

##### Mac OSX

1. Install brew: https://brew.sh/
2. Install rbenv: https://github.com/rbenv/rbenv
3. Install Ruby 2.6.3: `rbenv install 2.6.3`
4. Check out the project: `git clone git@github.com:rgould/dark_energy.git`
5. `cd dark_energy`
6. `bin/setup`

##### Windows/Linux

Set up instructions not available. If you try it out and figure it out, please add the instructions here :)

### Building the character sheet

Run `bin/compile` to build the HTML and CSS files. They can be found in `build/`

## Development notes

The project uses ActionView (the rendering system from Ruby on Rails) as a templating system.

You can learn more here: https://guides.rubyonrails.org/action_view_overview.html

Though knowing ERB may be enough for most use cases: https://github.com/ruby/erb

SCSS is used in favour of raw CSS, due to the highly hierarchical structure of the HTML. This made nesting CSS selectors much cleaner and more readable.

Layouts are done almost exclusively with CSS Grid. Column templates were calculated as fractions of the whole horizontal space (mostly done by hand using a printed version of the sheet and a ruler - it's possible some errors crept in).

### Box, subbox, inputbox

Most elements of the sheet are made of a component known as a "box". It has a structure like this:

```
box: {
  header {
    text {
      <header text here>
    }
  }
  box_content {
    <custom content here>
  }
}
```

See `views/_box.html.erb` for specifics.

Here's an example that has a `textara` as input:

```erb
<%= box _class: "box_conditions", header: "Conditions" do %>
  <textarea name="attr_conditions" class="attribute_input" value="" rows="4"/>
<% end %>
```

See the source code for many more examples.

`subbox` and `inputbox` are specialized versions of `box` with other defaults specified. Probably they could have better names
