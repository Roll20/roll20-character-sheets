module DarkEnergy
  module Helpers
    def version
      DarkEnergy::VERSION
    end

    def attr_input(attr, label=nil)
      render partial: "attribute", locals: { label: label ? label : attr.titleize, name: attr }
    end

    def box(type: nil, header: "", _class: "", header_border: true, header_input_label: nil, header_input_attr: nil, &block)
      render(layout: "box", locals: { _class: _class, header: header, type: type, header_border: header_border, header_input_label: header_input_label, header_input_attr: header_input_attr }, &block)
    end

    def box_with_header_input(header: "", _class: "", header_border: true, header_input_label:, header_input_attr:, &block)
      box(type: "box_with_header_input", header: header, _class: _class, header_border: header_border, header_input_label: header_input_label, header_input_attr: header_input_attr, &block)
    end

    def subbox(header: "", _class: "", header_border: true, &block)
      box(type: "subbox", header: header, _class: _class, header_border: header_border, &block)
    end

    def inputbox(header: "", _class: "", &block)
      box(type: "inputbox", header: header, _class: _class, header_border: true, &block)
    end

    def horizontal_box(header: "", _class: "", header_border: true, &block)
      box(type: "horizontal_box", header: header, _class: _class, header_border: header_border, &block)
    end

    def checkbox(_class: "", attr:, value: "1", label:)
      render(partial: "checkbox", locals: { _class: _class, attr: attr, value: value, label: label })
    end

    def weapon_proficiencies
      %w[
        simple_melee_weapons
        martial_melee_weapons
        simple_ranged_weapons
        martial_ranged_weapons
        exotic_weapons
        sidearms
        longarms
        heavy_weapons
        grenades/explosives
        improvised_weapons
        unarmed_strike
      ]
    end

    def talents
      {
        agility: { save: true },
        animal_handling: {},
        arcana: {},
        athletics: {},
        computer_use: {},
        art: { craft: true },
        drugs: { craft: true },
        device: { craft: true },
        cybernetics: { craft: true },
        runes: { craft: true },
        structure: { craft: true },
        tattoo: { craft: true },
        writing: { craft: true },
        deception: {},
        demolitions: {},
        disable_device: {},
        drive_or_pilot: { label: "Drive/Pilot" },
        intelligence: { save: true },
        intimidation: {},
        investigation: {},
        luck: { save: true, prof: false },
        might: { save: true },
        nature: {},
        perception: {},
        personality: { save: true },
        repair: {},
        science: {},
        spiritual: { save: true },
        stealth: {},
        streetwise: {},
        surgery: {},
        survival: {},
        treat_injury: {},
        vitality: { save: true, prof: false },
        knowledge1: { customizable: true, label: "Knowledge" },
        knowledge2: { customizable: true, label: "Knowledge" },
        tool1: { customizable: true, label: "Tool" },
        tool2: { customizable: true, label: "Tool" },
        tool3: { customizable: true, label: "Tool" },
        tool4: { customizable: true, label: "Tool" },
        tool5: { customizable: true, label: "Tool" },
        tool6: { customizable: true, label: "Tool" },
        _custom1: { customizable: true , fully: true},
        _custom2: { customizable: true , fully: true},
        _custom3: { customizable: true , fully: true},
        _custom4: { customizable: true , fully: true},
        _custom5: { customizable: true , fully: true},
        _custom6: { customizable: true , fully: true}
      }
    end

    def resistances
      %w[
        acid
        ballistic
        bludgeoning
        cold
        electricity
        fire
        force
        laser
        necrotic
        piercing
        plasma
        poison
        psychic
        radiant
        slashing
        thunder
      ]
    end

    def immunities
      %w[
        blinded
        charmed
        deafened
        disease
        frightened
        paralyzed
        petrified
        poisoned
        radiation
      ]
    end
  end
end
