require 'zeitwerk'

loader = Zeitwerk::Loader.for_gem
loader.setup
loader.eager_load

require "dark_energy/compiler"
require "dark_energy/version"

module DarkEnergy
  class Error < StandardError; end
end
